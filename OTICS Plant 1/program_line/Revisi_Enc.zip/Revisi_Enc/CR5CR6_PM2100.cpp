











#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SH110X.h>
#include <ModbusRTU.h>

#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

#define MODBUS_RX 17
#define MODBUS_TX 16
#define LORA_TX   27
#define LORA_RX   26

#define MODBUS_BAUD 19200
#define LORA_BAUD   9600

// Timing
#define SEND_INTERVAL 5000UL   // 5 detik per meter
#define MODBUS_TIMEOUT 2000UL   // timeout baca modbus 2 detik


#define REG_ADDRESS 2703
#define REG_COUNT 2

Adafruit_SH1106G display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);
SoftwareSerial mySerialRS485(MODBUS_RX, MODBUS_TX);
SoftwareSerial mySerialLora(LORA_TX, LORA_RX);
ModbusRTU mb;

uint16_t val[2];

struct MeterConfig {
  uint8_t id;
  const char* lineName;
  const char* pmName;
  const char* prefix;
  const char* suffix;
};

MeterConfig meters[] = {
  // CR5
  { 1, "CR5", "PM220", "0*y", "pru" },
  { 2, "CR5", "PM200", "8m7", "cuf" },

  // CR6
  { 3, "CR6", "PM220", "j4c", "&32" },
  { 4, "CR6", "PM200", "@3x", "dk?" }
};


const uint8_t meterCount = sizeof(meters) / sizeof(meters[0]);
uint8_t currentMeterIndex = 0;
unsigned long lastSendTime = 0;

float InttoFloatInverse(uint16_t Data0, uint16_t Data1) {
  union {
    uint32_t u32;
    float f;
  } conv;

  conv.u32 = ((uint32_t)Data1 << 16) | Data0;
  return conv.f;
}

bool cb(Modbus::ResultCode event, uint16_t transactionId, void* data) {
  return true;
}

bool readMeterEnergy(uint8_t slaveId, float &energyWh) {
  unsigned long startTime = millis();

  if (!mb.slave()) {
    if (!mb.readHreg(slaveId, REG_ADDRESS, val, REG_COUNT, cb)) {
      return false;
    }
  } else {
    return false;
  }

  while (mb.slave()) {
    mb.task();

    if (millis() - startTime > MODBUS_TIMEOUT) {
      return false;
    }
    delay(10);
  }

  float energy = InttoFloatInverse(val[1], val[0]);
  energyWh = energy * 1000.0f;
  return true;
}

void showDisplay(const MeterConfig &meter, float energyWh, bool success) {
  display.clearDisplay();
  display.setCursor(0, 0);
  display.print("Line   : ");
  display.println(meter.lineName);

  display.print("Meter  : ");
  display.println(meter.pmName);

  display.print("ID     : ");
  display.println(meter.id);

  display.print("Prefix : ");
  display.println(meter.prefix);

  display.print("Energy : ");
  if (success) {
    display.print(energyWh, 2);
    display.println(" Wh");
  } else {
    display.println("READ FAIL");
  }

  display.print("Suffix : ");
  display.println(meter.suffix);

  display.display();
}

void sendLoRa(const MeterConfig &meter, float energyWh) {
  String payload = String(meter.prefix) + "," + String(energyWh, 2) + "," + String(meter.suffix);
  mySerialLora.println(payload);
  Serial.println("LoRa TX: " + payload);
}

void setup() {
  Serial.begin(115200);

  mySerialRS485.begin(MODBUS_BAUD, SWSERIAL_8E1);
  mySerialLora.begin(LORA_BAUD);

  mb.begin(&mySerialRS485);
  mb.master();

  if (!display.begin(0x3C)) {
    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(SH110X_WHITE);
  display.setCursor(18, 20);
  display.println("App Run!");
  display.setCursor(8, 40);
  display.println("ENERGY 1.0 TPS");
  display.display();
  delay(1500);

  lastSendTime = millis() - SEND_INTERVAL; // supaya langsung kirim saat startup
}

void loop() {
  mb.task();

  if (millis() - lastSendTime >= SEND_INTERVAL) {
    lastSendTime = millis();

    const MeterConfig &meter = meters[currentMeterIndex];
    float energyWh = 0.0f;
    bool success = readMeterEnergy(meter.id, energyWh);

    showDisplay(meter, energyWh, success);

    if (success) {
      sendLoRa(meter, energyWh);
    } else {
      Serial.print("Failed reading slave ID ");
      Serial.println(meter.id);
    }

    currentMeterIndex++;
    if (currentMeterIndex >= meterCount) {
      currentMeterIndex = 0;
    }
  }
}