import React, { useState } from 'react';
import axios from 'axios';
import { Button, Container, Row, Col, Form, Alert, Card } from 'react-bootstrap';


function App() {
  const [file, setFile] = useState(null);
  const [jsonData, setJsonData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleFileChange = (e) => {
    setFile(e.target.files[0]);
    setError('');
  };

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const response = await axios.post('http://localhost:5000/upload', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      setJsonData(response.data);
      setError('');
    } catch (err) {
      setError('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Container fluid className="py-5">
      <Row className="justify-content-center">
        <Col xs={12} md={8} lg={6}>
          <Card className="shadow-lg">
            <Card.Body>
              <h2 className="text-center mb-4">Convert Excel/CSV to JSON</h2>
              <Form>
                <Form.Group controlId="fileUpload">
                  <Form.Label>Select a file (Excel/CSV)</Form.Label>
                  <Form.Control type="file" onChange={handleFileChange} />
                </Form.Group>
                <div className="d-flex justify-content-between">
                  <Button
                    variant="primary"
                    onClick={handleUpload}
                    disabled={loading}
                    className="mt-3"
                  >
                    {loading ? 'Uploading...' : 'Upload File'}
                  </Button>
                </div>
              </Form>
              {error && <Alert variant="danger" className="mt-3">{error}</Alert>}
            </Card.Body>
          </Card>

          {jsonData && (
            <Card className="mt-4">
              <Card.Body>
                <h5>Converted JSON Data</h5>
                <pre>{JSON.stringify(jsonData, null, 2)}</pre>
              </Card.Body>
            </Card>
          )}
        </Col>
      </Row>
    </Container>
  );
}

export default App;