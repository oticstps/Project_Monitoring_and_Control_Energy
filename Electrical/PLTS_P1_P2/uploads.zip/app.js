const express = require('express');
const multer = require('multer');
const xlsx = require('xlsx');
const csvParser = require('csv-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');  // Import cors

const app = express();
const port = 5000;

// Enable CORS
app.use(cors());  // Allow all origins to make requests

// Konfigurasi penyimpanan file menggunakan multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  },
});

const upload = multer({ storage: storage });

// Endpoint untuk mengunggah file dan mengonversinya ke JSON
app.post('/upload', upload.single('file'), (req, res) => {
  const filePath = req.file.path;
  const fileExtension = path.extname(req.file.originalname).toLowerCase();

  if (fileExtension === '.xlsx' || fileExtension === '.xls') {
    // Proses file Excel
    const workbook = xlsx.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_json(sheet);
    res.json(data);
  } else if (fileExtension === '.csv') {
    // Proses file CSV
    const results = [];
    fs.createReadStream(filePath)
      .pipe(csvParser())
      .on('data', (data) => results.push(data))
      .on('end', () => {
        res.json(results);
      });
  } else {
    res.status(400).json({ message: 'Format file tidak didukung' });
  }
});

// Menjalankan server
app.listen(port, () => {
  console.log(`Server berjalan di http://localhost:${port}`);
});